package com.jordonplays.client;

public class ClientModule {
    public final String name;
    public final String description;
    public boolean enabled;

    public ClientModule(String name, String description) {
        this.name = name;
        this.description = description;
    }

    public void toggle() {
        enabled = !enabled;
        ConfigManager.save();
    }
}
