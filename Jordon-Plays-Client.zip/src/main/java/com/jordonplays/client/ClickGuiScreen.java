package com.jordonplays.client;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public class ClickGuiScreen extends Screen {
    private static final int PANEL_X = 40;
    private static final int PANEL_Y = 35;
    private static final int PANEL_W = 300;
    private static final int ROW_H = 25;

    public ClickGuiScreen() {
        super(Text.literal("Jordon Plays Click GUI"));
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context, mouseX, mouseY, delta);
        int height = 42 + ModuleManager.MODULES.size() * ROW_H;
        context.fill(PANEL_X, PANEL_Y, PANEL_X + PANEL_W, PANEL_Y + height, 0xEE10121B);
        context.fill(PANEL_X, PANEL_Y, PANEL_X + PANEL_W, PANEL_Y + 3, 0xFF8B5CF6);
        context.drawText(textRenderer, "JORDON PLAYS CLIENT", PANEL_X + 12, PANEL_Y + 12, 0xFFB9A2FF, false);
        context.drawText(textRenderer, "Click a module to toggle", PANEL_X + 12, PANEL_Y + 27, 0xFF9CA3AF, false);

        int y = PANEL_Y + 42;
        for (ClientModule module : ModuleManager.MODULES) {
            boolean hovered = mouseX >= PANEL_X && mouseX <= PANEL_X + PANEL_W
                    && mouseY >= y && mouseY <= y + ROW_H;
            int bg = hovered ? 0xFF282B3B : 0xFF191B26;
            context.fill(PANEL_X + 8, y, PANEL_X + PANEL_W - 8, y + ROW_H - 2, bg);
            int color = module.enabled ? 0xFF60A5FA : 0xFFB8BCC8;
            context.drawText(textRenderer, module.name, PANEL_X + 17, y + 7, color, false);
            context.drawText(textRenderer, module.enabled ? "ON" : "OFF",
                    PANEL_X + PANEL_W - 38, y + 7, module.enabled ? 0xFF8B5CF6 : 0xFF777B88, false);
            y += ROW_H;
        }
        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button == GLFW.GLFW_MOUSE_BUTTON_LEFT) {
            int startY = PANEL_Y + 42;
            int index = (int) ((mouseY - startY) / ROW_H);
            if (mouseX >= PANEL_X && mouseX <= PANEL_X + PANEL_W
                    && index >= 0 && index < ModuleManager.MODULES.size()
                    && mouseY >= startY) {
                ModuleManager.MODULES.get(index).toggle();
                return true;
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
