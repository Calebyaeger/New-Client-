package com.jordonplays.client;

import java.util.ArrayList;
import java.util.List;

public final class ModuleManager {
    public static final List<ClientModule> MODULES = new ArrayList<>();

    private ModuleManager() {}

    public static void init() {
        MODULES.clear();
        MODULES.add(new ClientModule("Array List", "Show enabled modules in a HUD list."));
        MODULES.add(new ClientModule("Coordinates", "Display your current coordinates."));
        MODULES.add(new ClientModule("FPS Display", "Display current frames per second."));
        MODULES.add(new ClientModule("Keystrokes", "Show movement key presses."));
        MODULES.add(new ClientModule("Armor HUD", "Display equipped armor information."));
        MODULES.add(new ClientModule("Crosshair", "Toggle a custom crosshair overlay."));
        MODULES.add(new ClientModule("Bright UI", "Use brighter client interface accents."));
        MODULES.add(new ClientModule("Notifications", "Show client module toggle notifications."));
    }

    public static ClientModule find(String name) {
        return MODULES.stream().filter(m -> m.name.equals(name)).findFirst().orElse(null);
    }
}
