package com.jordonplays.client;

import net.fabricmc.loader.api.FabricLoader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

public final class ConfigManager {
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("jordonplaysclient.properties");

    private ConfigManager() {}

    public static void save() {
        Properties properties = new Properties();
        for (ClientModule module : ModuleManager.MODULES) {
            properties.setProperty(module.name, Boolean.toString(module.enabled));
        }
        try (var output = Files.newOutputStream(FILE)) {
            properties.store(output, "Jordon Plays Client settings");
        } catch (IOException exception) {
            System.err.println("[Jordon Plays Client] Could not save config: " + exception.getMessage());
        }
    }

    public static void load() {
        if (!Files.exists(FILE)) return;
        Properties properties = new Properties();
        try (var input = Files.newInputStream(FILE)) {
            properties.load(input);
            for (ClientModule module : ModuleManager.MODULES) {
                module.enabled = Boolean.parseBoolean(properties.getProperty(module.name, "false"));
            }
        } catch (IOException exception) {
            System.err.println("[Jordon Plays Client] Could not load config: " + exception.getMessage());
        }
    }
}
